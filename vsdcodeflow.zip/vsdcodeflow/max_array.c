#include "unique.h"

int main(void){
    uniq_print_header("max_array");
    int a[] = {42,-7,19,88,3,88,5,-100,37};
    int n = sizeof(a)/sizeof(a[0]), max=a[0];
    for(int i=1;i<n;i++) if(a[i]>max) max=a[i];
    printf("Array length=%d, Max=%d\n", n, max);
    return 0;
}
